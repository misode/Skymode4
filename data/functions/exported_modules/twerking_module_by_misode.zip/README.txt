Twerking module made by misode (Twitter: @misoloo)

### Description ###
Sneak near an oak, spruce, birch, jungle or acacia saplings to let them grow.
A happyVillager particle will be visible at saplings that have a chance to grow.
Currently, only 4 variations of each type is able to spawn because they have to be manually programmed.

### Installation ###
1. Move the files inside "functions" into "(world)/data/functions"
2. Move the files inside "loot_tables" into "(world)/data/loot_tables"
3. Rejoin the world or run "/reload"
4. Add "twerking:clock" to a function that is constantly running.
   If you have no other functions running, enter the following command in chat:
   "/gamerule gameLoopFunction twerking:clock"
5. Run "/function twerking:init" to initialize this module.
6. You are now ready to twerk!

### Problems ###
If you have any problems with the installation or working of this modules,
please contact me on Twitter (@misoloo) or on Discord (misode#8166)
